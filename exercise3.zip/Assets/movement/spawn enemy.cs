using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using Unity.VisualScripting.Dependencies.Sqlite;
using UnityEngine;

public class spawnenemy : MonoBehaviour
{
    // Start is called before the first frame update
  [SerializeField] GameObject _enemyprefab;
  [SerializeField] float _minimumspawntime;
  [SerializeField] float _maximumspawntime;
 
   
    
}
